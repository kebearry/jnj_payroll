exports.payslip = {
    'payslip': {
        title: '',
        name: '',
        generatedMonth: '',
        grossIncome: '',
        employeeCPF: '',
        additionalDeduction: '',
        netIncome: '',
        email: ''
    }
}
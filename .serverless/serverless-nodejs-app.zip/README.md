# Payslip Generation and Mail Service

## Description
![Payslip Generation Preview](https://i.imgur.com/2LEVy6f.png)
![Email Preview](https://i.imgur.com/wuQS8PC.png)
This is a pure nodeJS solution to solution to generate and communicate payslip for every employee. While this is an automated cron job that has been scheduled once a month on the first day of the month at 00.00, this UI is for demonstration purpose to trigger the payslip generation and sending of emails.  A live environment for this app can be accessed at [Payslip Generator](https://5rd9wixb27.execute-api.ap-southeast-1.amazonaws.com/dev/)

### Technical Contraints
* AWS Free Tier Limit
* MailTrap Free Tier Limit (<500 total emails to be sent and throttled email per second)

### Packages Used and Purposes Behind Them
| Name              | Purpose                                                  |
|-------------------|----------------------------------------------------------|
| csv-parse         | parser to convert CSV text input into arrays or objects. |
| email-templates   | send custom email templates for nodeJS                   |
| express           | nodeJS web application framework                         |
| lodash            | web development facilitator with ootb utility functions  |
| moment            | JS date library for date utility functions               |
| node-cron         | task scheduler                                           |
| nodemailer        | facilitates email sending                                |
| html-to-text      | generates text content from html for nodemailer emails   |
| optimist          | parse CLI arguments                                      |
| pug               | template engine for nodeJS                               |
| serverless-http   | deploy nodeJS code to cloud infrastructure               |
| stream-transform  | object transformation for stream data                    |